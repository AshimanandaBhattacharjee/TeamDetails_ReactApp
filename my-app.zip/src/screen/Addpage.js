import './Addpage.css';
import Input from '../components/input/Input';
import Title from '../components/title/Title';
//import Button from '../components/button/Button';
import BasicTable from '../components/table/BasicTable';
import Button from '@mui/material/Button';
//import { useState } from 'react'
//import HtmlTable from '../components/htmlTable/HtmlTable';

export default function Addpage() {
    // const [showTable, setShowTable] = useState(false)

    const dataLength = 1;

    const handleShowTable = () => {
        console.log("Ashim")

        // setShowTable(!showTable)
    }
    return (
        <div className='Addpage'>
            <Title heading="Team Details" />
            <Input type="text" field="Employee Name: " class="fill" />
            <Input type="text" field="Employee Title: " class="fill" />
            <Input type="file" field="Employee Pic: " class="fill1" />
            <Input type="text" field="Employee Hobbies: " class="fill" />
            {/* <Button type="button" class="btn" value="Add"/> */}
            <Button
                variant="contained"
                color="secondary"
                size="small"
                onClick={handleShowTable}
            >
                Add
            </Button>

            {/* {show && <HtmlTable/>} */}

            {/* {showTable && <BasicTable />} */}
            {/* {show && <BasicTable/>} */}

            {/* <HtmlTable/> */}
            <BasicTable/>
        </div>
    );
}

//export default Addpage;