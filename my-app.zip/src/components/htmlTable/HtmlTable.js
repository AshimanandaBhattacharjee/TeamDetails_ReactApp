import "./HtmlTable.css";

export default function HtmlTable() {
    return (
        <table>
            <tr>
                <th>Employee Name</th>
                <th>Employee Title</th>
                <th>Employee Pic</th>
                <th>Employee Hobbies</th>
            </tr>
            <tr>
                <td>Ashimananda Bhattacharjee</td>
                <td>Intern</td>
                <td>(to be uploaded)</td>
                <td>Music, Table-Tennis</td>
            </tr>
            <tr>
                <td>Hirak</td>
                <td>GET</td>
                <td>(to be uploaded)</td>
                <td> </td>
            </tr>
        </table>
    );
}


//export default Button;